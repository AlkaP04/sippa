const flavours = [

    {
        name: "Pomegranate",
        image: "images/pomegranate.png.png",
        background: "#f5b8c6",
        textColor: "#a7244a",
        description:
        "Bold, fruity and naturally refreshing. A beautiful burst of pomegranate in every sip."
    },

    {
        name: "Tropical Guava",
        image: "images/guava.png.png",
        background: "#cfe5cc",
        textColor: "#3f7b50",
        description:
        "Soft tropical sweetness with a fresh guava twist made for sunny days."
    },

    {
        name: "Golden Mango",
        image: "images/mango.png.png",
        background: "#f7d47c",
        textColor: "#a85b00",
        description:
        "Golden, juicy and full of tropical flavour. Summer happiness in a bottle."
    },

   

];


let currentIndex = 0;

const hero = document.querySelector(".hero");
const bottle = document.getElementById("heroBottle");
const title = document.getElementById("heroFlavor");
const description = document.getElementById("heroDescription");
const dots = document.querySelectorAll(".flavour-dot");


function changeFlavour(index){

    const flavour = flavours[index];

    bottle.classList.remove("change");

    void bottle.offsetWidth;

    bottle.classList.add("change");

    title.classList.remove("text-change");

void title.offsetWidth;

title.classList.add("text-change");


    /*
       Bottle മാറുന്ന animation-ന്റെ middle point-ൽ
       image/text/background മാറ്റുന്നു
    */

    setTimeout(() => {

        bottle.src = flavour.image;

        title.textContent = flavour.name;

        description.textContent = flavour.description;

        hero.style.background = flavour.background;

        title.style.color = flavour.textColor;


        dots.forEach(dot => {
            dot.classList.remove("active");
        });

        dots[index].classList.add("active");

    }, 300);


    currentIndex = index;
}


/* DOT CLICK */

dots.forEach(dot => {

    dot.addEventListener("click", () => {

        const index = Number(dot.dataset.index);

        changeFlavour(index);

    });

});


/* AUTOMATIC FLAVOUR CHANGE */

setInterval(() => {

    let nextIndex =
        (currentIndex + 1) % flavours.length;

    changeFlavour(nextIndex);

}, 5000);


/* NAVBAR GLASS EFFECT */

window.addEventListener("scroll", () => {

    const navbar =
        document.querySelector(".navbar");

    if(window.scrollY > 60){

        navbar.classList.add("scrolled");

    }else{

        navbar.classList.remove("scrolled");

    }

});


/* SCROLL REVEAL */

const revealElements =
    document.querySelectorAll(".reveal");


const observer =
new IntersectionObserver((entries) => {

    entries.forEach((entry) => {

        if(entry.isIntersecting){

            entry.target.classList.add("active");

        }

    });

},{
    threshold:0.15
});


revealElements.forEach(element => {

    observer.observe(element);

});


/* MOUSE PARALLAX EFFECT */

document.addEventListener("mousemove", (e) => {

    const x =
        (window.innerWidth / 2 - e.pageX) / 50;

    const y =
        (window.innerHeight / 2 - e.pageY) / 50;

    document.querySelectorAll(".fruit")
        .forEach((fruit, index) => {

            const speed =
                (index + 1) * 0.35;

            fruit.style.marginLeft =
                `${x * speed}px`;

            fruit.style.marginTop =
                `${y * speed}px`;

        });

});
// JOIN US FORM

const form = document.getElementById("subscribeForm");
const email = document.getElementById("emailInput");
const message = document.getElementById("successMessage");

if (form) {
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        if (email.value.trim() !== "") {
            message.style.display = "block";
            message.textContent = "Thanks! Stay fresh 🍹";
            email.value = "";
        }
    });
}